﻿import { Filter } from './filter';
import { MarketBase } from './market-base';

export class MarketDefinitionBaseMap {
    Id: number;
    Name: string;
    MarketBase: MarketBase;
    Filters: Filter[];
    DataRefreshType: string;
}

