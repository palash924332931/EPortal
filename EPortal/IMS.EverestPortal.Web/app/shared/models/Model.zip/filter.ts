﻿export class Filter {
    Id: number;
    Name: string;
    Criteria: string;
    Values: string[];
    IsEnabled: boolean;
}