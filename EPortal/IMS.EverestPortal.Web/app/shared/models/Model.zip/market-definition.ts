﻿import { MarketDefinitionBaseMap } from './market-definition-base-map';

export class MarketDefinition {
    Id: number;
    Name: string;
    Description: string;
    MarketDefinitionBaseMaps: MarketDefinitionBaseMap[];
}
