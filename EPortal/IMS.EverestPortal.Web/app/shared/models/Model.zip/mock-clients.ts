﻿import { Filter } from './filter';
import { MarketBase } from './market-base';
import { MarketDefinitionBaseMap } from './market-definition-base-map';
import { MarketDefinition } from './market-definition';
import { Client } from './client';


export const MARKET_BASES: MarketBase[] = [
    { Id: 1, Name: 'ATC3 N02B', Description: '', Filters: [{ Id: 1, Name: 'filter1', Criteria: 'ATC3', Values: ['N02B'], IsEnabled: true }] },
    { Id: 2, Name: 'Manufacturer ALCON', Description: '', Filters: [{ Id: 2, Name: 'filter2', Criteria: 'Manufacturer', Values: ['ALCON'], IsEnabled: true }] }
];

export const FILTER3: Filter =
    { Id: 3, Name: 'filter3', Criteria: 'molecule', Values: ['XYZ'], IsEnabled: true };

export const FILTER4: Filter =
    { Id: 4, Name: 'filter4', Criteria: 'branding', Values: ['branded'], IsEnabled: true };

export const BASE_MAP1: MarketDefinitionBaseMap = {
    Id: 1, Name: 'ATC3 N02B', MarketBase: MARKET_BASES[0], Filters: [FILTER3], DataRefreshType: 'dynamic'
};

export const BASE_MAP2: MarketDefinitionBaseMap = {
    Id: 1, Name: 'Manufacturer ALCON', MarketBase: MARKET_BASES[1], Filters: [FILTER4], DataRefreshType: 'dynamic'
};

export const MARKET_DEF1: MarketDefinition = {
    Id: 1, Name: 'Pain Market', Description: '', MarketDefinitionBaseMaps: [BASE_MAP1, BASE_MAP2]
};

export const MARKET_DEF2: MarketDefinition = {
    Id: 1, Name: 'Respiratory Market', Description: '', MarketDefinitionBaseMaps: [BASE_MAP1, BASE_MAP2]
};

export const MARKET_DEF3: MarketDefinition = {
    Id: 1, Name: 'Child Care Market', Description: '', MarketDefinitionBaseMaps: [BASE_MAP1, BASE_MAP2]
};

export const CLIENTS: Client[] = [
    { Id: 1, Name: 'Client 1', IsMyClient: true, MarketDefinitions: [MARKET_DEF1] },
    { Id: 2, Name: 'Client 2', IsMyClient: false, MarketDefinitions: [MARKET_DEF2] },
    { Id: 3, Name: 'Client 3', IsMyClient: true, MarketDefinitions: [MARKET_DEF3] },
    { Id: 4, Name: 'Client 4', IsMyClient: true, MarketDefinitions: [MARKET_DEF2] },
    { Id: 5, Name: 'Client 5', IsMyClient: true, MarketDefinitions: [MARKET_DEF1] },
    { Id: 6, Name: 'Client 6', IsMyClient: false, MarketDefinitions: [MARKET_DEF2] },
    { Id: 7, Name: 'Client 7', IsMyClient: true, MarketDefinitions: [MARKET_DEF1] },
    { Id: 8, Name: 'Client 8', IsMyClient: true, MarketDefinitions: [MARKET_DEF2] },
    { Id: 9, Name: 'Client 9', IsMyClient: false, MarketDefinitions: [MARKET_DEF1] }
];