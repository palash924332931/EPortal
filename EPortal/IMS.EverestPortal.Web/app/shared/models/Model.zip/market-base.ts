﻿import { Filter } from './filter';

export class MarketBase {
    Id: number;
    Name: string;
    Description: string;
    Filters: Filter[];
}
