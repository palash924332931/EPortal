// JavaScript Document

$(document).ready(function(){
    // Defining the local dataset
    var client = ['Client6', 'Client6', 'Client9', 'Client12', 'Client16', 'Client23'];
	var client2 = ['Client1', 'Client2', 'Client3', 'Client4', 'Client5', 'Client6', 'Client6', 'Client7', 'Client8', 'Client9','Client10', 'Client11', 'Client12', 'Client13', 'Client14', 'Client15', 'Client16', 'Client17', 'Client18', 'Client19'];
    
    // Constructing the suggestion engine
    var client = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        local: client
    });
	
	var client2 = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        local: client2
    });
    
    // Initializing the typeahead
    $('.typeahead').typeahead({
        hint: true,
        highlight: true, /* Enable substring highlighting */
        minLength: 1 /* Specify minimum characters required for showing result */
    },
    {
        name: 'client',
        source: client
    }),
	
	$('.typeahead2').typeahead({
        hint: true,
        highlight: true, /* Enable substring highlighting */
        minLength: 1 /* Specify minimum characters required for showing result */
    },
	
	{
        name: 'client2',
        source: client2
    });
	
	 
	
	
	
	
});  