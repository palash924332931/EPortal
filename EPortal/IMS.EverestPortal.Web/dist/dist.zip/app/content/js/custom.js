$(window).load(function(){
$('article#viewMarket').click(function() { 
    window.location.assign("ViewMarket.html")
});

$('.edit').click(function(event){
    event.stopImmediatePropagation();
     window.location.assign("edit.html")
});

$('.delete').click(function(event){
    event.stopImmediatePropagation();
    
	
	var r = confirm("Are you sure you want to delete");
            if (r == true) {
               var $target = $(this).parents('article');
  $target.remove();
            } else {
               return false;
            }
	
	
	
});


$('.panel-heading h4 a input[type=checkbox]').on('click', function(e){
    e.stopPropagation();
	
})
$('#collapseOne').on('show.bs.collapse', function(e){
    if( ! $('.panel-heading h4 a input[type=checkbox]').is(':checked') )
    {
       
		
    }
});

});

 function do_this(){

        var checkboxes = document.getElementsByName('approve[]');
	   
        var button = document.getElementById('toggle');
	   
	 	
        var label=button.textContent;
	    
	 
	 	if(label=='Select All')
			{
				for (var i in checkboxes){
                checkboxes[i].checked = 'FALSE';
            }
				button.textContent = 'Deselect All'
			}else{
            for (var i in checkboxes){
                checkboxes[i].checked = '';
            }
            button.textContent = 'Select All';
        }
	 
	 
	 
	   
	 
    }






function do_this1(){

        var checkboxes = document.getElementsByName('approve1[]');
	   
        var button = document.getElementById('toggle1');
	   
	 	
        var label=button.textContent;
	    
	 
	 	if(label=='Select All')
			{
				for (var i in checkboxes){
                checkboxes[i].checked = 'FALSE';
            }
				button.textContent = 'Deselect All'
			}else{
            for (var i in checkboxes){
                checkboxes[i].checked = '';
            }
            button.textContent = 'Select All';
        }
	 
	 
	 
	   
	 
    }


function addPack() {
  var myButtonClasses = document.getElementById("AddMktDef").classList;

  if (myButtonClasses.contains("disabled")) {
    myButtonClasses.remove("disabled");
	  
	  document.getElementById("AddMktDef").disabled = false; 
  }
  
}



function AddtoMktDef()
{
	 var addgrpButt = document.getElementById("groupFac").classList;
	var remgrpButt=document.getElementById("remGroup").classList;
	var delmktDefButton=document.getElementById("delMktDef").classList;

  if (addgrpButt.contains("disabled")) {
    addgrpButt.remove("disabled");
	  
	  document.getElementById("groupFac").disabled = false; 
  }
	
	if (remgrpButt.contains("disabled")) {
    remgrpButt.remove("disabled");
	  
	  document.getElementById("remGroup").disabled = false; 
  }
	
	
	if (delmktDefButton.contains("disabled")) {
    delmktDefButton.remove("disabled");
	  
	  document.getElementById("delMktDef").disabled = false; 
  }
	
}
	
    


function showTable()
{
	var packTable=document.getElementById("packSearchTable").classList;
	packTable.remove("hidden");
}

function showAdSearch() {



    var adSerch = document.getElementById('adSrch');
    var adSearch = adSerch.textContent;



    if (adSearch == 'Advance Search') {


        var barcodeShow = document.getElementById("adSrchBarcode").classList;
        barcodeShow.remove("hidden");

        var pfcShow = document.getElementById("adSrchPFC").classList;
        pfcShow.remove("hidden");

        var flaogcShow = document.getElementById("adSrchFlagging").classList;
        flaogcShow.remove("hidden");

        var BrandingShow = document.getElementById("adSrchBranding").classList;
        BrandingShow.remove("hidden");

        adSerch.textContent = 'Basic Search'
    }

    else {




        var barcodeShow = document.getElementById("adSrchBarcode").classList;
        barcodeShow.add("hidden");

        var pfcShow = document.getElementById("adSrchPFC").classList;
        pfcShow.add("hidden");

        var flaogcShow = document.getElementById("adSrchFlagging").classList;
        flaogcShow.add("hidden");

        var BrandingShow = document.getElementById("adSrchBranding").classList;
        BrandingShow.add("hidden");

        adSerch.textContent = 'Advance Search'



    }

}
 


